// server.js
const express = require('express');
const mongoose = require('mongoose');
const scheduleRoutes = require('./scheduleRoutes');
const announcementRoutes = require('./announcementRoutes');
const attendanceRoutes = require('./attendanceRoutes');

const app = express();

app.use(express.json());
// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/your-database', { useNewUrlParser: true, useUnifiedTopology: true });

// Use middleware for authentication
app.use(authenticateUser);

// Use routes
app.use('/api/schedules', scheduleRoutes);
app.use('/api/announcements', announcementRoutes);
app.use('/api/attendance', attendanceRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
